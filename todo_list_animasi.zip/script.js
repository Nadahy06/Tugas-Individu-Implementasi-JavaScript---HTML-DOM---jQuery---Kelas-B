$(document).ready(function () {
  $('#addTask').click(function () {
    let taskText = $('#taskInput').val().trim();

    if (taskText === '') {
      alert('Tugas tidak boleh kosong!');
      return;
    }

    let taskItem = $('<li></li>').text(taskText);
    let deleteBtn = $('<span class="delete">✖</span>');
    taskItem.append(deleteBtn);

    $('#taskList').append(taskItem.hide().slideDown(400));
    $('#taskInput').val('');
  });

  $('#taskList').on('click', 'li', function () {
    $(this).toggleClass('done');
    $(this).css('transform', 'scale(0.98)').delay(200).queue(function(next){
      $(this).css('transform', 'scale(1)');
      next();
    });
  });

  $('#taskList').on('click', '.delete', function (e) {
    e.stopPropagation();
    $(this).parent().slideUp(400, function () {
      $(this).remove();
    });
  });
});